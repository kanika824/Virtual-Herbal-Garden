document.addEventListener('DOMContentLoaded', () => {
  const scroll = new LocomotiveScroll({
    el: document.querySelector('body'),
    lerp: 0.02,
    smooth: true
  });
  console.log("Locomotive Scroll initialized");

  function showInfo(infoId) {
    console.log(`Showing info for: ${infoId}`);
    const allInfoBoxes = document.querySelectorAll('.info-box');
    allInfoBoxes.forEach(box => {
      if (box.id !== infoId) {
        box.classList.remove('open');
      }
    });

    const infoBox = document.getElementById(infoId);
    if (infoBox) {
      infoBox.classList.toggle('open');
    }
  }

  document.querySelectorAll('.image').forEach(image => {
    image.addEventListener('click', function() {
      showInfo(this.getAttribute('data-info'));
    });
  });
});
